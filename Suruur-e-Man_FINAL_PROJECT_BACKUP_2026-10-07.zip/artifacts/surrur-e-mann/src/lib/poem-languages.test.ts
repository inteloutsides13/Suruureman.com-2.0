import { describe, expect, it } from "vitest";
import { getPoemLanguage, getPoemLanguageLabel, POEM_LANGUAGES } from "./poem-languages";

describe("poem language options", () => {
  it("keeps every existing language and adds the three distinct new options", () => {
    expect(POEM_LANGUAGES.map(({ value }) => value)).toEqual([
      "urdu",
      "punjabi",
      "arabic",
      "persian",
      "farsi",
      "hindi",
      "siraiki",
      "english",
      "spanish",
      "punjabi-shahmukhi",
    ]);
    expect(getPoemLanguage("english")?.label).toBe("English");
    expect(getPoemLanguage("spanish")?.label).toBe("Spanish / Español");
    expect(getPoemLanguage("punjabi-shahmukhi")?.label).toBe("Punjabi (Shahmukhi)");
    expect(getPoemLanguage("punjabi-shahmukhi")?.description).toContain("Shahmukhi script");
    expect(getPoemLanguageLabel("punjabi")).toBe("Punjabi");
    expect(getPoemLanguageLabel("legacy-language")).toBe("legacy-language");
  });
});
