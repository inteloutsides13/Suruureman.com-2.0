import { useState, useCallback } from "react";

const TOKEN_KEY = "sem_admin_token";
const EMAIL_KEY = "sem_admin_email";
const ROLE_KEY = "sem_admin_role";
const NAME_KEY = "sem_admin_name";
const USER_ID_KEY = "sem_admin_user_id";

export type AdminRole = "developer" | "admin" | "contributor";

export function hasIrabAccessRole(role: unknown): role is AdminRole {
  return role === "developer" || role === "admin" || role === "contributor";
}

export function getAdminToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function getAdminRole(): AdminRole | null {
  return localStorage.getItem(ROLE_KEY) as AdminRole | null;
}

export function getAdminName(): string | null {
  return localStorage.getItem(NAME_KEY);
}

export function getAdminUserId(): number | null {
  const v = localStorage.getItem(USER_ID_KEY);
  return v ? parseInt(v) : null;
}

export function isDeveloper(): boolean {
  return localStorage.getItem(ROLE_KEY) === "developer";
}

export function isContributor(): boolean {
  return localStorage.getItem(ROLE_KEY) === "contributor";
}

export function clearAdminSession(): void {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(EMAIL_KEY);
  localStorage.removeItem(ROLE_KEY);
  localStorage.removeItem(NAME_KEY);
  localStorage.removeItem(USER_ID_KEY);
}

export function useAdminAuth() {
  const [token, setTokenState] = useState<string | null>(() => localStorage.getItem(TOKEN_KEY));
  const [email, setEmailState] = useState<string | null>(() => localStorage.getItem(EMAIL_KEY));
  const [role, setRoleState] = useState<AdminRole | null>(() => localStorage.getItem(ROLE_KEY) as AdminRole | null);
  const [name, setNameState] = useState<string | null>(() => localStorage.getItem(NAME_KEY));

  const login = useCallback((newToken: string, newEmail: string, newRole?: string, newName?: string, newUserId?: number) => {
    localStorage.setItem(TOKEN_KEY, newToken);
    localStorage.setItem(EMAIL_KEY, newEmail);
    const r = (newRole === "developer" || newRole === "admin" || newRole === "contributor") ? newRole : "admin";
    localStorage.setItem(ROLE_KEY, r);
    if (newName) localStorage.setItem(NAME_KEY, newName);
    if (newUserId) localStorage.setItem(USER_ID_KEY, String(newUserId));
    setTokenState(newToken);
    setEmailState(newEmail);
    setRoleState(r as AdminRole);
    setNameState(newName ?? null);
  }, []);

  const logout = useCallback(() => {
    clearAdminSession();
    setTokenState(null);
    setEmailState(null);
    setRoleState(null);
    setNameState(null);
  }, []);

  return {
    token,
    email,
    role,
    name,
    login,
    logout,
    isAuthenticated: !!token,
    isDeveloper: role === "developer",
    isAdmin: role === "admin" || role === "developer",
    isContributor: role === "contributor",
  };
}

let redirectingToLogin = false;

export async function adminFetch(path: string, options: RequestInit = {}): Promise<Response> {
  const token = getAdminToken();
  const response = await fetch(path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
  });

  if (response.status === 401 && !redirectingToLogin) {
    redirectingToLogin = true;
    clearAdminSession();
    window.location.href = "/admin/login";
    setTimeout(() => { redirectingToLogin = false; }, 3000);
  }

  return response;
}

/** Fetch utility for the contributor portal — same token, different redirect */
export async function contributorFetch(path: string, options: RequestInit = {}): Promise<Response> {
  const token = getAdminToken();
  const response = await fetch(path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
  });

  if (response.status === 401 && !redirectingToLogin) {
    redirectingToLogin = true;
    clearAdminSession();
    window.location.href = "/admin/login";
    setTimeout(() => { redirectingToLogin = false; }, 3000);
  }

  return response;
}
