import { useEffect } from "react";

const SITE_NAME = "Suruureman";
const DEFAULT_DESCRIPTION =
  "Suruureman — سُرُور مَن — A treasury of classical Urdu poetry. Explore ghazals, nazms, and more from the masters of Urdu literature.";

function upsertMeta(selector: string, attr: string, content: string) {
  let el = document.querySelector(selector) as HTMLMetaElement | null;
  if (!el) {
    el = document.createElement("meta");
    const [attrName, attrValue] = attr.split("=");
    el.setAttribute(attrName, attrValue);
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

function getOgImage(path?: string): string {
  const base = window.location.origin;
  const base_url = import.meta.env.BASE_URL || "/";
  return path
    ? path.startsWith("http")
      ? path
      : `${base}${base_url}${path.replace(/^\//, "")}`
    : `${base}${base_url}logo.jpg`;
}

export interface SeoOptions {
  title?: string;
  description?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  ogType?: "website" | "article";
}

export function useSeo({
  title,
  description,
  ogTitle,
  ogDescription,
  ogImage,
  ogType = "website",
}: SeoOptions = {}) {
  useEffect(() => {
    const fullTitle = title ? `${title} | ${SITE_NAME}` : SITE_NAME;
    const desc = description || DEFAULT_DESCRIPTION;
    const resolvedOgImage = getOgImage(ogImage);

    document.title = fullTitle;

    upsertMeta('meta[name="description"]', "name=description", desc);

    upsertMeta('meta[property="og:title"]', "property=og:title", ogTitle || fullTitle);
    upsertMeta('meta[property="og:description"]', "property=og:description", ogDescription || desc);
    upsertMeta('meta[property="og:image"]', "property=og:image", resolvedOgImage);
    upsertMeta('meta[property="og:type"]', "property=og:type", ogType);
    upsertMeta('meta[property="og:site_name"]', "property=og:site_name", SITE_NAME);
    upsertMeta('meta[property="og:url"]', "property=og:url", window.location.href);

    upsertMeta('meta[name="twitter:card"]', "name=twitter:card", "summary_large_image");
    upsertMeta('meta[name="twitter:title"]', "name=twitter:title", ogTitle || fullTitle);
    upsertMeta('meta[name="twitter:description"]', "name=twitter:description", ogDescription || desc);
    upsertMeta('meta[name="twitter:image"]', "name=twitter:image", resolvedOgImage);

    return () => {
      document.title = SITE_NAME;
    };
  }, [title, description, ogTitle, ogDescription, ogImage, ogType]);
}
