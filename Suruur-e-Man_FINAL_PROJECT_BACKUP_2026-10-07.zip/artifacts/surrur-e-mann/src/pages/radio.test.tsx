import { render, screen } from "@testing-library/react";
import type { ReactNode } from "react";
import { describe, expect, it, vi } from "vitest";
import RadioPage from "./radio";

const mockUseRadioPlayer = vi.hoisted(() => vi.fn());

vi.mock("@/hooks/use-radio-player", () => ({
  useRadioPlayer: mockUseRadioPlayer,
}));

vi.mock("@/components/radio-player", () => ({
  RadioPlayer: () => <div aria-label="Radio player" />,
}));

vi.mock("@/hooks/use-seo", () => ({
  useSeo: vi.fn(),
}));

vi.mock("wouter", () => ({
  Link: ({ href, children }: { href: string; children: ReactNode }) => <a href={href}>{children}</a>,
}));

function radioState(overrides: Record<string, unknown> = {}) {
  return {
    status: "offline",
    streamUrl: null,
    nowPlaying: null,
    message: "Radio stream is not configured.",
    schedules: [],
    station: null,
    retry: vi.fn(),
    playback: "idle",
    volume: 0.5,
    setVolume: vi.fn(),
    togglePlayback: vi.fn(),
    ...overrides,
  };
}

describe("public Radio listener-facing wording", () => {
  it("describes a configured stream as a browser playback option", () => {
    mockUseRadioPlayer.mockReturnValue(radioState({
      status: "available",
      streamUrl: "https://radio.example.test/stream",
      schedules: [{
        id: 1,
        name: "Evening poetry",
        timezone: "Europe/Berlin",
        daysOfWeek: "[1,2,3,4,5]",
        startLocalTime: "18:00",
        endLocalTime: "19:00",
        effectiveFrom: null,
        effectiveUntil: null,
        programName: "Evening poetry",
        attribution: null,
        scheduleState: "current",
      }],
    }));

    render(<RadioPage />);

    expect(screen.getByText("Stream configuration available")).toBeInTheDocument();
    expect(screen.getByText("Configured window")).toBeInTheDocument();
    expect(screen.getByText(/press play to test playback in this browser/i)).toBeInTheDocument();
    expect(screen.queryByText(/^live$/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/^on air$/i)).not.toBeInTheDocument();
    expect(screen.queryByText(/^broadcasting$/i)).not.toBeInTheDocument();
  });

  it("explains unavailable public playback without claiming an emergency broadcast", () => {
    mockUseRadioPlayer.mockReturnValue(radioState());

    render(<RadioPage />);

    expect(screen.getByText("Public playback unavailable")).toBeInTheDocument();
    expect(screen.getByText(/no usable public stream link is configured/i)).toBeInTheDocument();
    expect(screen.queryByText(/emergency broadcast active|broadcasting emergency|live emergency|on air/i)).not.toBeInTheDocument();
  });

  it("labels schedules as configuration and distinguishes an empty schedule", () => {
    mockUseRadioPlayer.mockReturnValue(radioState());

    render(<RadioPage />);

    expect(screen.getByText("Configured schedule")).toBeInTheDocument();
    expect(screen.getByText("ابھی کوئی شیڈول ترتیب نہیں دیا گیا۔")).toBeInTheDocument();
    expect(screen.getByText(/موجودہ نشریات کی تصدیق نہیں/)).toBeInTheDocument();
  });
});