import { motion } from "framer-motion";
import { ArrowUpRight, CalendarClock, Headphones, Radio, Send, Signal, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { RadioPlayer } from "@/components/radio-player";
import { useRadioPlayer } from "@/hooks/use-radio-player";
import { useSeo } from "@/hooks/use-seo";

const listenNotes = [
  {
    icon: Headphones,
    title: "اپنے براؤزر میں سنیے",
    body: "پلے دبانے سے اس براؤزر میں موجود اسٹریم لنک آزمایا جائے گا۔ یہ بٹن صرف آپ کے مقامی پلے بیک کو کنٹرول کرتا ہے۔",
  },
  {
    icon: Signal,
    title: "ترتیب، نشریات نہیں",
    body: "اسٹریم لنک یا شیڈول صرف ترتیب دی گئی معلومات دکھاتا ہے؛ یہ موجودہ نشریات یا کسی آٹومیشن رَن ٹائم کی تصدیق نہیں کرتا۔",
  },
  {
    icon: Send,
    title: "نہ چلے تو کیا کریں",
    body: "اگر ترتیب کی تفصیل لوڈ نہ ہو تو دوبارہ کوشش کریں۔ اگر لنک دستیاب نہ ہو تو بعد میں واپس آئیے؛ یہاں غیر مصدقہ لائیو دعویٰ نہیں کیا جائے گا۔",
  },
];

function scheduleDays(value: string) {
  const names = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  try {
    const days = JSON.parse(value) as unknown;
    if (Array.isArray(days) && days.length > 0) {
      return days.map((day) => typeof day === "number" && names[day] ? names[day] : String(day)).join(" · ");
    }
  } catch {
    if (value.trim()) return value;
  }
  return "Weekly schedule";
}

export default function RadioPage() {
  useSeo({
    title: "Suruur FM | Urdu Literary Radio",
    description: "Suruur FM is the future radio room of Suruureman — a truthful listening experience for Urdu literature and poetry.",
    ogTitle: "Suruur FM | Suruureman",
  });

  const radio = useRadioPlayer();
  const isUnavailable = radio.status === "offline" || radio.status === "empty";
  const publicStatus =
    radio.status === "loading"
      ? {
          label: "Loading stream configuration",
          detail: "Checking whether a usable public stream link is configured.",
        }
      : radio.status === "available"
        ? {
            label: "Stream configuration available",
            detail: "Press play to test playback in this browser. The stream has not been verified as live.",
          }
        : radio.status === "error"
          ? {
              label: "Stream configuration unavailable",
              detail: "We could not load the stream details. Use the retry control in the player.",
            }
          : {
              label: "Public playback unavailable",
              detail: "No usable public stream link is configured for listeners yet.",
            };

  return (
    <div className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[44rem] bg-[radial-gradient(ellipse_at_70%_14%,hsl(var(--radio-ember)/.14),transparent_55%),radial-gradient(ellipse_at_15%_20%,hsl(var(--accent)/.08),transparent_45%)]" />
      <div className="pointer-events-none absolute left-[8%] top-40 h-72 w-px bg-gradient-to-b from-transparent via-accent/30 to-transparent" />

      <main className="relative mx-auto max-w-7xl px-4 pb-20 pt-12 sm:px-6 sm:pt-20 lg:px-8 lg:pb-28">
        <div className="mb-10 flex items-center gap-3 text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
          <span>Suruur-e-Man</span>
          <span className="h-px w-8 bg-accent/40" />
          <span className="text-accent">Radio</span>
        </div>

        <section className="grid items-center gap-12 lg:grid-cols-[1.05fr_.95fr] lg:gap-20">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <p className="mb-5 flex items-center gap-3 text-xs uppercase tracking-[0.28em] text-accent">
              <span className="h-px w-8 bg-accent" />
              A future frequency for the written word
            </p>
            <h1 className="max-w-3xl font-urdu text-5xl leading-[1.8] text-foreground sm:text-6xl lg:text-7xl" dir="rtl">
              لفظ، آواز، <span className="text-accent text-glow-gold">سُرور</span>
            </h1>
            <p className="mt-5 max-w-xl font-heading text-2xl leading-relaxed text-foreground/90 sm:text-3xl">
              Suruur FM
            </p>
            <p className="mt-6 max-w-xl font-urdu text-xl leading-[2] text-muted-foreground sm:text-2xl" dir="rtl">
              شاعری، محفوظ کلام اور ادبی آوازوں کے لیے ایک مخصوص سننے کی جگہ۔ پلے بیک کی حالت صرف اسی براؤزر کے بارے میں بتائی جائے گی۔
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <a href="#listen" className="inline-flex items-center gap-2 rounded-full bg-accent px-5 py-3 text-sm font-medium text-accent-foreground transition-transform hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background">
                ریڈیو پلیئر
                <ArrowUpRight size={15} aria-hidden="true" />
              </a>
              <Link href="/poems" className="inline-flex items-center gap-2 rounded-full border border-accent/25 px-5 py-3 text-sm text-foreground transition-colors hover:border-accent hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">
                شاعری پڑھیے
              </Link>
            </div>
          </motion.div>

          <motion.div id="listen" initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.8, delay: 0.1 }}>
            <RadioPlayer />
            <div className="mt-4 flex items-start justify-end gap-3 rounded-xl border border-accent/10 bg-card/25 p-3 text-right">
              <Radio size={12} aria-hidden="true" />
              <div>
                <p className="text-[10px] uppercase tracking-[0.18em] text-accent/80">{publicStatus.label}</p>
                <p className="mt-1 text-xs leading-5 text-muted-foreground">{publicStatus.detail}</p>
              </div>
            </div>
          </motion.div>
        </section>

        <section className="mt-24 border-y border-accent/10 py-10 sm:mt-32 sm:py-14">
          <div className="grid gap-8 lg:grid-cols-[.9fr_1.1fr] lg:gap-20">
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-accent">Honest status</p>
              <h2 className="mt-4 font-urdu text-4xl leading-[1.8] text-foreground sm:text-5xl" dir="rtl">
                نشریات وہی، جو حقیقت میں موجود ہوں
              </h2>
            </div>
            <div className="max-w-2xl">
              <p className="font-urdu text-xl leading-[2] text-muted-foreground sm:text-2xl" dir="rtl">
                ریڈیو سرورِ من کی ایک سچی توسیع کے طور پر تیار کیا جا رہا ہے۔ یہ صفحہ ترتیب دی گئی معلومات اور اسی براؤزر کے پلے بیک کو الگ الگ دکھاتا ہے؛ کسی اسٹریم لنک سے موجودہ نشریات ثابت نہیں ہوتیں۔
              </p>
              <div className="mt-7 flex items-center gap-3 text-sm">
                <span className={`h-2 w-2 rounded-full ${isUnavailable ? "bg-muted-foreground/50" : radio.status === "error" ? "bg-destructive" : radio.status === "loading" ? "bg-accent animate-pulse" : "bg-accent"}`} />
                <span className="font-urdu text-lg text-foreground" dir="rtl">{radio.status === "loading" ? "اسٹریم کی ترتیب دیکھی جا رہی ہے…" : isUnavailable ? "سامعین کے لیے قابلِ استعمال اسٹریم لنک موجود نہیں۔" : radio.status === "error" ? "ریڈیو اسٹریم کی تفصیل لوڈ نہیں ہو سکی؛ دوبارہ کوشش کریں۔" : "اسٹریم لنک موجود ہے؛ پلے دبانے سے براؤزر پلے بیک آزمایا جا سکتا ہے۔"}</span>
              </div>
            </div>
          </div>
        </section>

        <section className="mt-20 sm:mt-28">
          <div className="flex flex-col justify-between gap-4 border-b border-accent/10 pb-6 sm:flex-row sm:items-end">
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-accent">Listening guide</p>
              <h2 className="mt-3 font-urdu text-4xl leading-[1.8] text-foreground sm:text-5xl" dir="rtl">اس محفل میں کیا ہوگا</h2>
            </div>
            <Sparkles size={22} className="text-accent/70" aria-hidden="true" />
          </div>
          <div className="mt-8 grid gap-px overflow-hidden rounded-2xl border border-accent/10 bg-accent/10 md:grid-cols-3">
            {listenNotes.map((note, index) => (
              <article key={note.title} className="bg-card/65 p-6 transition-colors hover:bg-card/80 sm:p-8">
                <div className="flex items-center justify-between">
                  <note.icon size={21} strokeWidth={1.4} className="text-accent" aria-hidden="true" />
                  <span className="font-heading text-sm text-accent/60">0{index + 1}</span>
                </div>
                <h3 className="mt-12 font-urdu text-2xl leading-[1.8] text-foreground" dir="rtl">{note.title}</h3>
                <p className="mt-3 font-urdu text-lg leading-[2] text-muted-foreground" dir="rtl">{note.body}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="mt-20 sm:mt-28" aria-labelledby="radio-schedule-heading">
          <div className="flex flex-col justify-between gap-4 border-b border-accent/10 pb-6 sm:flex-row sm:items-end">
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-accent">Configured schedule</p>
              <h2 id="radio-schedule-heading" className="mt-3 font-urdu text-4xl leading-[1.8] text-foreground sm:text-5xl" dir="rtl">نشریاتی پروگرام</h2>
              <p className="mt-3 max-w-2xl font-urdu text-lg leading-[2] text-muted-foreground" dir="rtl">
                اوقات <bdi dir="ltr">{radio.station?.timezone ?? "Europe/Berlin"}</bdi> کے مطابق دکھائے جائیں گے۔ یہ ترتیب دیے گئے اوقات ہیں، موجودہ نشریات کی تصدیق نہیں۔
              </p>
            </div>
            <CalendarClock size={22} className="text-accent/70" aria-hidden="true" />
          </div>
          {radio.schedules.length === 0 ? (
            <div className="mt-8 rounded-2xl border border-dashed border-accent/20 bg-card/20 p-10 text-center sm:p-14">
              <p className="font-urdu text-2xl leading-[1.8] text-muted-foreground" dir="rtl">ابھی کوئی شیڈول ترتیب نہیں دیا گیا۔</p>
              <p className="mt-2 font-urdu text-lg leading-[2] text-muted-foreground/70" dir="rtl">منظور شدہ پروگرام کا شیڈول دستیاب ہوتے ہی یہاں دکھایا جائے گا؛ یہ لائیو نشریات کی تصدیق نہیں ہوگا۔</p>
            </div>
          ) : (
            <div className="mt-8 grid gap-3 md:grid-cols-2">
              {radio.schedules.map((schedule) => (
                <article key={schedule.id} className="rounded-2xl border border-accent/15 bg-card/45 p-5 transition-colors hover:border-accent/30 hover:bg-card/60">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-[10px] uppercase tracking-[0.2em] text-accent">{schedule.scheduleState === "current" ? "Configured window" : "Upcoming configured window"}</p>
                      <h3 className="mt-2 font-heading text-xl text-foreground">{schedule.programName || schedule.name}</h3>
                    </div>
                    <CalendarClock size={17} className="mt-1 shrink-0 text-accent/70" aria-hidden="true" />
                  </div>
                  <p className="mt-4 text-sm text-muted-foreground">{schedule.startLocalTime}–{schedule.endLocalTime} · {scheduleDays(schedule.daysOfWeek)} · {schedule.timezone}</p>
                  {schedule.occurrenceLocalDate && <p className="mt-2 text-xs text-muted-foreground/80">Configured local date: {schedule.occurrenceLocalDate}</p>}
                  {schedule.attribution && <p className="mt-2 text-xs text-muted-foreground/80">{schedule.attribution}</p>}
                </article>
              ))}
            </div>
          )}
        </section>

        <section className="mt-20 overflow-hidden rounded-2xl border border-accent/15 bg-card/35 p-7 sm:mt-28 sm:p-10 lg:p-14">
          <div className="grid gap-8 lg:grid-cols-[1fr_auto] lg:items-end">
            <div>
              <p className="font-urdu text-4xl leading-[1.8] text-accent" dir="rtl">تب تک، لفظوں کے قریب رہیے</p>
              <h2 className="mt-4 max-w-2xl font-heading text-3xl leading-tight text-foreground sm:text-4xl" dir="ltr">
                The radio begins with the written word.
              </h2>
              <p className="mt-4 max-w-xl text-sm leading-7 text-muted-foreground sm:text-base" dir="ltr">
                Explore the collection that gives this future frequency its reason to exist — poems, poets, and the many ways a line can stay with you.
              </p>
            </div>
            <div className="flex flex-wrap gap-3 lg:justify-end">
              <Link href="/poems" className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm text-primary-foreground transition-colors hover:bg-primary/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">
                شاعری دیکھیے
                <ArrowUpRight size={15} aria-hidden="true" />
              </Link>
              <Link href="/contact" className="inline-flex items-center gap-2 rounded-full border border-accent/25 px-5 py-3 text-sm text-foreground transition-colors hover:border-accent hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">
                پیغام بھیجیے
              </Link>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}