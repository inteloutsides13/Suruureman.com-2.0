import { Router, type IRouter } from "express";
import { and, asc, eq } from "drizzle-orm";
import { db } from "@workspace/db";
import { radioPlaylistsTable, radioSchedulesTable, radioSettingsTable } from "@workspace/db/schema";
import {
  DEFAULT_RADIO_TIMEZONE,
  findScheduleOccurrence,
} from "../lib/radioSchedule.js";

const router: IRouter = Router();

const PUBLIC_SETTING_KEYS = [
  "station_name",
  "enabled",
  "public_stream_url",
  "stream_hostname",
  "stream_path",
  "stream_protocol",
  "stream_format",
  "stream_bitrate_kbps",
  "status_message",
  "schedule_timezone",
  "now_playing_title",
  "now_playing_artist",
  "now_playing_program",
  "now_playing_content_type",
  "now_playing_artwork_url",
  "now_playing_updated_at",
] as const;

function settingValue(settings: Record<string, string>, key: string): string | null {
  const value = settings[key]?.trim();
  return value || null;
}

function parseOptionalNumber(value: string | null): number | null {
  if (!value) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function isPrivateHostname(hostname: string): boolean {
  return hostname === "localhost" ||
    hostname.endsWith(".localhost") ||
    hostname.endsWith(".local") ||
    hostname.endsWith(".internal") ||
    hostname.endsWith(".lan") ||
    hostname === "0.0.0.0" ||
    hostname === "::1" ||
    hostname.startsWith("10.") ||
    hostname.startsWith("192.168.") ||
    hostname.startsWith("169.254.") ||
    /^172\.(1[6-9]|2\d|3[0-1])\./.test(hostname) ||
    /^127\./.test(hostname);
}

function safePublicHostname(value: string | null): string | null {
  if (!value || !/^[a-z0-9.-]+$/i.test(value)) return null;
  const hostname = value.toLowerCase();
  return isPrivateHostname(hostname) ? null : value;
}

function safePublicUrl(value: string | null): string | null {
  if (!value) return null;
  try {
    const url = new URL(value);
    if (!["http:", "https:"].includes(url.protocol) || url.username || url.password) return null;
    const hostname = url.hostname.toLowerCase();
    return isPrivateHostname(hostname) ? null : url.toString();
  } catch {
    return null;
  }
}

router.get("/status", async (req, res) => {
  try {
    const rows = await db
      .select({ key: radioSettingsTable.key, value: radioSettingsTable.value })
      .from(radioSettingsTable);
    const settings: Record<string, string> = {};
    for (const row of rows) {
      if ((PUBLIC_SETTING_KEYS as readonly string[]).includes(row.key)) settings[row.key] = row.value;
    }

    const enabled = settings.enabled === "true";
    const streamUrl = enabled ? safePublicUrl(settingValue(settings, "public_stream_url")) : null;
    const artworkUrl = safePublicUrl(settingValue(settings, "now_playing_artwork_url"));
    const hasNowPlaying = Boolean(streamUrl && settingValue(settings, "now_playing_title"));
    const nowPlaying = hasNowPlaying
      ? {
          title: settingValue(settings, "now_playing_title"),
          artist: settingValue(settings, "now_playing_artist"),
          program: settingValue(settings, "now_playing_program"),
          contentType: settingValue(settings, "now_playing_content_type"),
          artworkUrl,
          updatedAt: settingValue(settings, "now_playing_updated_at"),
        }
      : null;

    const now = new Date();
    const schedules = await db
      .select({
        id: radioSchedulesTable.id,
        name: radioSchedulesTable.name,
        timezone: radioSchedulesTable.timezone,
        daysOfWeek: radioSchedulesTable.daysOfWeek,
        startLocalTime: radioSchedulesTable.startLocalTime,
        endLocalTime: radioSchedulesTable.endLocalTime,
        effectiveFrom: radioSchedulesTable.effectiveFrom,
        effectiveUntil: radioSchedulesTable.effectiveUntil,
        programName: radioSchedulesTable.programName,
        attribution: radioSchedulesTable.attribution,
        priority: radioSchedulesTable.priority,
      })
      .from(radioSchedulesTable)
      .innerJoin(radioPlaylistsTable, eq(radioPlaylistsTable.id, radioSchedulesTable.playlistId))
      .where(and(
        eq(radioSchedulesTable.status, "active"),
        eq(radioPlaylistsTable.status, "active"),
      ))
      .orderBy(asc(radioSchedulesTable.startLocalTime), asc(radioSchedulesTable.name));

    const scheduledOccurrences = schedules
      .map((schedule) => {
        const occurrence = findScheduleOccurrence({
          timezone: schedule.timezone,
          daysOfWeek: schedule.daysOfWeek,
          startLocalTime: schedule.startLocalTime,
          endLocalTime: schedule.endLocalTime,
          effectiveFrom: schedule.effectiveFrom,
          effectiveUntil: schedule.effectiveUntil,
        }, now);
        return occurrence ? {
          ...schedule,
          scheduleState: occurrence.state,
          occurrenceStart: occurrence.startsAt.toISOString(),
          occurrenceEnd: occurrence.endsAt.toISOString(),
          occurrenceLocalDate: occurrence.localDate,
        } : null;
      })
      .filter((schedule): schedule is NonNullable<typeof schedule> => Boolean(schedule))
      .sort((left, right) => {
        const stateOrder = left.scheduleState === right.scheduleState
          ? 0
          : left.scheduleState === "current" ? -1 : 1;
        if (stateOrder !== 0) return stateOrder;
        const occurrenceOrder = left.occurrenceStart.localeCompare(right.occurrenceStart);
        if (occurrenceOrder !== 0) return occurrenceOrder;
        return right.priority - left.priority;
      });

    res.json({
      station: {
        name: settingValue(settings, "station_name") ?? "Radio Suruur FM",
        hostname: safePublicHostname(settingValue(settings, "stream_hostname")) ?? "radio.suruureman.com",
        path: settingValue(settings, "stream_path"),
        protocol: settingValue(settings, "stream_protocol") ?? "https",
        format: settingValue(settings, "stream_format") ?? "MP3",
        bitrateKbps: parseOptionalNumber(settingValue(settings, "stream_bitrate_kbps")) ?? 96,
        timezone: settingValue(settings, "schedule_timezone") ?? DEFAULT_RADIO_TIMEZONE,
      },
      // `available` means a usable public stream configuration exists. It is
      // not a provider/runtime health check and must not be presented as live.
      status: streamUrl ? "available" : "offline",
      available: Boolean(streamUrl),
      streamUrl,
      message: settingValue(settings, "status_message") ?? "Radio stream is not configured.",
      nowPlaying,
      schedules: scheduledOccurrences,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to read public Radio status");
    res.status(500).json({ message: "Radio information could not be loaded" });
  }
});

export default router;