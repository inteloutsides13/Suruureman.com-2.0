import { useEffect, useState } from "react";
import { CalendarClock } from "lucide-react";

type PublicProgramme = {
  id: number;
  titleEn: string;
  titleUr: string;
  descriptionEn: string | null;
  descriptionUr: string | null;
  programmeType: string;
  programmeDate: string;
  startTime: string;
  endTime: string;
  externalLink: string | null;
  publicNote: string | null;
};

function displayDate(value: string) {
  return new Intl.DateTimeFormat("en", { dateStyle: "full", timeZone: "Asia/Dubai" })
    .format(new Date(`${value}T12:00:00+04:00`));
}

export function RadioCalendarPublic() {
  const [programmes, setProgrammes] = useState<PublicProgramme[]>([]);

  useEffect(() => {
    let active = true;
    fetch("/api/radio-calendar/programmes", { cache: "no-store" })
      .then((response) => response.ok ? response.json() : null)
      .then((data) => {
        if (active && Array.isArray(data?.programmes)) setProgrammes(data.programmes);
      })
      .catch(() => {
        // Calendar failure is intentionally isolated from the GoCast player and radio status.
      });
    return () => { active = false; };
  }, []);

  if (!programmes.length) return null;

  return (
    <section className="mt-16 border-t border-accent/10 pt-10 sm:mt-20 sm:pt-12" aria-labelledby="radio-calendar-heading">
      <div className="mb-7 flex items-center justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.22em] text-primary">Asia/Dubai</p>
          <h2 id="radio-calendar-heading" className="mt-2 font-urdu text-3xl leading-[1.8] text-foreground sm:text-4xl" dir="rtl">آنے والے پروگرام</h2>
        </div>
        <CalendarClock size={21} className="shrink-0 text-accent/70" aria-hidden="true" />
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        {programmes.map((programme) => (
          <article key={programme.id} className="rounded-2xl border border-accent/15 bg-card/45 p-5 transition-colors hover:border-primary/50">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-heading text-xl text-foreground">{programme.titleEn}</h3>
              <span className="rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 text-xs text-foreground">{programme.programmeType}</span>
            </div>
            <p className="mt-1 font-urdu text-lg text-accent" dir="rtl">{programme.titleUr}</p>
            <p className="mt-3 text-sm text-muted-foreground">{displayDate(programme.programmeDate)} · {programme.startTime.slice(0, 5)}–{programme.endTime.slice(0, 5)} · Asia/Dubai</p>
            {programme.descriptionEn && <p className="mt-3 text-sm leading-6 text-foreground/80">{programme.descriptionEn}</p>}
            {programme.descriptionUr && <p className="mt-2 font-urdu text-base leading-8 text-foreground/80" dir="rtl">{programme.descriptionUr}</p>}
            {programme.publicNote && <p className="mt-3 border-l-2 border-accent/50 pl-3 text-sm text-accent">{programme.publicNote}</p>}
            {programme.externalLink && <a className="mt-3 inline-block text-sm text-accent underline-offset-4 hover:underline" href={programme.externalLink} target="_blank" rel="noreferrer">More information</a>}
          </article>
        ))}
      </div>
    </section>
  );
}
