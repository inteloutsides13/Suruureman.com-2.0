import { describe, expect, it } from "vitest";
import { getCanonicalUrl, isNonIndexableRoute } from "./use-seo";

describe("SEO route metadata helpers", () => {
  it("uses the production origin and keeps only the category filter in poem canonicals", () => {
    expect(getCanonicalUrl("/poems/", "?category=ghazal&sort=latest"))
      .toBe("https://suruureman.com/poems?category=ghazal");
  });

  it("drops tracking and search parameters from other canonical URLs", () => {
    expect(getCanonicalUrl("/poets/12/", "?utm_source=preview"))
      .toBe("https://suruureman.com/poets/12");
    expect(getCanonicalUrl("/search", "?q=ghazal"))
      .toBe("https://suruureman.com/search");
  });

  it("marks private and access-restricted route families non-indexable", () => {
    expect(isNonIndexableRoute("/admin/login")).toBe(true);
    expect(isNonIndexableRoute("/contributor/activate/secret-token")).toBe(true);
    expect(isNonIndexableRoute("/contributor-status")).toBe(true);
    expect(isNonIndexableRoute("/irab")).toBe(true);
    expect(isNonIndexableRoute("/poems/812")).toBe(false);
  });
});
