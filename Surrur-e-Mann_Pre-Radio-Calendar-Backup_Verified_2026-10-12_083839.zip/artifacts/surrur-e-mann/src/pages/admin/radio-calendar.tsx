import { useCallback, useEffect, useState } from "react";
import { CalendarDays, ChevronLeft, ChevronRight, Edit3, LoaderCircle, Plus, Save, X } from "lucide-react";
import { AdminLayout } from "@/components/admin-layout";
import { adminFetch, useAdminAuth } from "@/hooks/use-admin-auth";

const types = ["Auto DJ", "Live Radio", "Recorded Show", "Poetry Hour", "TikTok Live", "Announcement/Break"];
type Programme = {
  id: number; titleEn: string; titleUr: string; descriptionEn: string | null; descriptionUr: string | null;
  programmeType: string; programmeDate: string; startTime: string; endTime: string;
  timezone: "Asia/Dubai"; externalLink: string | null; publicNote: string | null;
  status: "draft" | "published" | "cancelled";
};
type Form = Omit<Programme, "id" | "status">;

function dubaiToday() {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dubai", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}
function moveDate(date: string, days: number) {
  const value = new Date(`${date}T00:00:00Z`);
  value.setUTCDate(value.getUTCDate() + days);
  return value.toISOString().slice(0, 10);
}
function emptyForm(date: string): Form {
  return { titleEn: "", titleUr: "", descriptionEn: null, descriptionUr: null, programmeType: types[0],
    programmeDate: date, startTime: "18:00", endTime: "19:00", timezone: "Asia/Dubai", externalLink: null, publicNote: null };
}
function fieldValue(value: string | null) { return value ?? ""; }

export default function AdminRadioCalendar() {
  const { role } = useAdminAuth();
  const [startDate, setStartDate] = useState(dubaiToday);
  const [programmes, setProgrammes] = useState<Programme[]>([]);
  const [form, setForm] = useState<Form>(() => emptyForm(dubaiToday()));
  const [editingId, setEditingId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const response = await adminFetch(`/api/admin/radio-calendar/programmes?startDate=${startDate}`);
      const data = await response.json().catch(() => null);
      if (!response.ok) throw new Error(data?.message || "Calendar database unavailable. Configure RADIO_CALENDAR_DATABASE_URL after provisioning the separate database.");
      if (!Array.isArray(data?.programmes)) throw new Error("Calendar response was incomplete.");
      setProgrammes(data.programmes);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Calendar could not be loaded.");
    } finally { setLoading(false); }
  }, [startDate]);

  useEffect(() => { void load(); }, [load]);

  function edit(programme: Programme) {
    const { id, status: _status, ...values } = programme;
    setEditingId(id);
    setForm(values);
    setNotice(null);
  }
  function resetForm() { setEditingId(null); setForm(emptyForm(startDate)); }

  async function save(event: React.FormEvent) {
    event.preventDefault(); setSaving(true); setError(null); setNotice(null);
    const payload = {
      ...form,
      descriptionEn: form.descriptionEn?.trim() || null,
      descriptionUr: form.descriptionUr?.trim() || null,
      externalLink: form.externalLink?.trim() || null,
      publicNote: form.publicNote?.trim() || null,
    };
    try {
      const response = await adminFetch(editingId ? `/api/admin/radio-calendar/programmes/${editingId}` : "/api/admin/radio-calendar/programmes",
        { method: editingId ? "PUT" : "POST", body: JSON.stringify(payload) });
      const data = await response.json().catch(() => null);
      if (!response.ok) throw new Error(data?.message || "Programme could not be saved.");
      resetForm(); setNotice(editingId ? "Programme updated." : "Draft programme added."); await load();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Programme could not be saved.");
    } finally { setSaving(false); }
  }

  async function changeStatus(programme: Programme, action: "publish" | "cancel") {
    setError(null); setNotice(null);
    try {
      const response = await adminFetch(`/api/admin/radio-calendar/programmes/${programme.id}/${action}`, { method: "POST" });
      const data = await response.json().catch(() => null);
      if (!response.ok) throw new Error(data?.message || "Programme status could not be changed.");
      setNotice(action === "publish" ? "Programme published." : "Programme cancelled.");
      await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Programme status could not be changed."); }
  }

  const days = Array.from({ length: 7 }, (_, index) => moveDate(startDate, index));
  const dateLabel = (value: string) => new Intl.DateTimeFormat("en", { weekday: "long", month: "short", day: "numeric", timeZone: "Asia/Dubai" }).format(new Date(`${value}T12:00:00+04:00`));
  const inputClass = "w-full rounded-lg border border-accent/20 bg-background px-3 py-2.5 text-sm text-foreground outline-none focus:border-accent";
  const textField = (label: string, key: keyof Form, options: { required?: boolean; type?: string; maxLength?: number } = {}) => (
    <label className="grid gap-1.5 text-sm text-muted-foreground">{label}<input className={inputClass} type={options.type ?? "text"} required={options.required} maxLength={options.maxLength}
      value={String(form[key] ?? "")} onChange={(event) => setForm((current) => ({ ...current, [key]: event.target.value }))} /></label>
  );

  return (
    <AdminLayout>
      <div className="mx-auto max-w-6xl space-y-8">
        <header className="flex flex-wrap items-center justify-between gap-4">
          <div><p className="text-xs uppercase tracking-[.2em] text-primary">Independent calendar · Asia/Dubai</p><h1 className="mt-2 font-heading text-3xl text-foreground">Radio Programme Calendar</h1><p className="mt-2 text-sm text-muted-foreground">Manage dated programmes separately from radio playback and status.</p></div>
          <CalendarDays className="text-accent" size={28} />
        </header>
        {role !== "admin" && role !== "developer" && <p className="text-sm text-destructive">Only Admin and Developer accounts can manage the calendar.</p>}
        {(error || notice) && <p role={error ? "alert" : "status"} className={`rounded-lg border p-3 text-sm ${error ? "border-destructive/30 text-destructive" : "border-accent/20 text-accent"}`}>{error || notice}</p>}
        <div className="grid gap-8 xl:grid-cols-[1fr_1.2fr]">
          <form onSubmit={save} className="space-y-4 rounded-2xl border border-accent/15 bg-card/40 p-5">
            <h2 className="font-heading text-xl">{editingId ? "Edit programme" : "Add programme"}</h2>
            <div className="grid gap-3 sm:grid-cols-2">{textField("Title (English)", "titleEn", { required: true, maxLength: 200 })}{textField("عنوان (اردو)", "titleUr", { required: true, maxLength: 200 })}</div>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="grid gap-1.5 text-sm text-muted-foreground">Programme type<select className={inputClass} value={form.programmeType} onChange={(event) => setForm((current) => ({ ...current, programmeType: event.target.value }))}>{types.map((type) => <option key={type}>{type}</option>)}</select></label>
              {textField("Date", "programmeDate", { required: true, type: "date" })}
              {textField("Start time", "startTime", { required: true, type: "time" })}{textField("End time", "endTime", { required: true, type: "time" })}
            </div>
            <p className="text-xs text-accent">All times use Asia/Dubai.</p>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="grid gap-1.5 text-sm text-muted-foreground">Description (English)<textarea className={inputClass} maxLength={2000} value={fieldValue(form.descriptionEn)} onChange={(event) => setForm((current) => ({ ...current, descriptionEn: event.target.value }))} /></label>
              <label className="grid gap-1.5 text-sm text-muted-foreground">تفصیل (اردو)<textarea dir="rtl" className={inputClass} maxLength={2000} value={fieldValue(form.descriptionUr)} onChange={(event) => setForm((current) => ({ ...current, descriptionUr: event.target.value }))} /></label>
            </div>
            {textField("External link (optional)", "externalLink", { type: "url", maxLength: 2000 })}
            <label className="grid gap-1.5 text-sm text-muted-foreground">Public note (optional)<textarea className={inputClass} maxLength={500} value={fieldValue(form.publicNote)} onChange={(event) => setForm((current) => ({ ...current, publicNote: event.target.value }))} /></label>
            <div className="flex flex-wrap gap-2">
              <button disabled={saving} className="inline-flex items-center gap-2 rounded-lg bg-accent px-4 py-2.5 text-sm font-medium text-accent-foreground disabled:opacity-50">{saving ? <LoaderCircle className="animate-spin" size={15} /> : editingId ? <Save size={15} /> : <Plus size={15} />}{saving ? "Saving…" : editingId ? "Save changes" : "Save draft"}</button>
              {editingId && <button type="button" onClick={resetForm} className="inline-flex items-center gap-2 rounded-lg border border-accent/20 px-4 py-2.5 text-sm"><X size={15} />Cancel edit</button>}
            </div>
          </form>
          <section className="space-y-4">
            <div className="flex items-center justify-between rounded-xl border border-accent/15 bg-card/30 p-3">
              <button aria-label="Previous week" onClick={() => setStartDate(moveDate(startDate, -7))} className="rounded-lg p-2 text-accent hover:bg-accent/10"><ChevronLeft size={20} /></button>
              <span className="text-sm font-medium">Week of {dateLabel(startDate)}</span>
              <button aria-label="Next week" onClick={() => setStartDate(moveDate(startDate, 7))} className="rounded-lg p-2 text-accent hover:bg-accent/10"><ChevronRight size={20} /></button>
            </div>
            {loading && <p className="flex items-center gap-2 text-sm text-muted-foreground"><LoaderCircle className="animate-spin" size={16} />Loading calendar…</p>}
            {!loading && days.map((day) => <div key={day} className="rounded-xl border border-accent/10 bg-card/25 p-4">
              <h3 className="mb-3 font-heading text-lg text-accent">{dateLabel(day)}</h3>
              {programmes.filter((programme) => programme.programmeDate.slice(0, 10) === day).length === 0 && <p className="text-sm text-muted-foreground">No programmes</p>}
              <div className="space-y-3">{programmes.filter((programme) => programme.programmeDate.slice(0, 10) === day).map((programme) => <article key={programme.id} className="rounded-lg border border-accent/10 bg-background/60 p-3">
                <div className="flex flex-wrap items-start justify-between gap-2"><div><p className="font-medium">{programme.titleEn} <span className="font-urdu text-accent" dir="rtl">{programme.titleUr}</span></p><p className="mt-1 text-xs text-muted-foreground">{programme.startTime.slice(0, 5)}–{programme.endTime.slice(0, 5)} · {programme.programmeType} · <span className={programme.status === "published" ? "text-emerald-400" : programme.status === "cancelled" ? "text-destructive" : "text-amber-400"}>{programme.status}</span></p></div>
                  <div className="flex gap-2"><button aria-label={`Edit ${programme.titleEn}`} onClick={() => edit(programme)} className="rounded border border-accent/20 p-1.5 text-accent"><Edit3 size={14} /></button>{programme.status === "draft" && <button onClick={() => void changeStatus(programme, "publish")} className="rounded border border-accent/20 px-2 py-1 text-xs text-accent">Publish</button>}{programme.status === "published" && <button onClick={() => void changeStatus(programme, "cancel")} className="rounded border border-destructive/30 px-2 py-1 text-xs text-destructive">Cancel</button>}</div>
                </div>
              </article>)}</div>
            </div>)}
          </section>
        </div>
      </div>
    </AdminLayout>
  );
}
