# Independent Radio Programme Calendar

The calendar uses one PostgreSQL database and one table, separate from the website and existing Radio data. It does not use the proposed application baseline or Radio migrations 0001–0004. The API never creates schema automatically.

## Manual setup required

Provision a **new, dedicated PostgreSQL database resource** whose project/instance is separate from the website and production database. The current workspace does not identify a provider-specific external database resource, so an operator must provision and verify that distinct resource before configuration.

After approval, manually run `docs/radio-calendar-schema.sql` against that new database only. Then configure the connection as the secret/environment setting **`RADIO_CALENDAR_DATABASE_URL`** for the API service. Do not copy or reuse `DATABASE_URL`, `SOURCE_DATABASE_URL`, or any production credentials. The server has no fallback to those settings; with the calendar setting absent, only the calendar endpoints return unavailable.

No database resource has been created and no schema/setup command has been run.

## Model

`radio_calendar_programmes` has only: identity `id`; English/Urdu title and description; programme type; date; start/end time; fixed `Asia/Dubai` timezone; optional external link and public note; draft/published/cancelled status; and created/updated timestamps.

Public reads return published rows for a seven-date range. Admin and Developer writes use the existing `requireAdmin` middleware, which retains its existing JWT, active-account, and revocation checks. Calendar data queries use only `RADIO_CALENDAR_DATABASE_URL`.

