import assert from "node:assert/strict";
import test from "node:test";
import {
  calendarWeekRange,
  radioCalendarInput,
  resolveRadioCalendarConnection,
} from "./radioCalendar.js";

test("calendar connection requires its dedicated setting and never falls back", () => {
  assert.throws(() => resolveRadioCalendarConnection({
    DATABASE_URL: "postgresql://redacted.invalid/redacted",
    SOURCE_DATABASE_URL: "postgresql://redacted.invalid/redacted",
  }), /RADIO_CALENDAR_DATABASE_URL/);
  assert.throws(() => resolveRadioCalendarConnection({
    RADIO_CALENDAR_DATABASE_URL: "https://calendar.invalid/db",
  }), /PostgreSQL URL/);
  assert.equal(
    resolveRadioCalendarConnection({ RADIO_CALENDAR_DATABASE_URL: "postgresql://redacted.invalid/redacted" }),
    "postgresql://redacted.invalid/redacted",
  );
});

test("calendar accepts only the specified programme fields, types, and Dubai timezone", () => {
  const valid = {
    titleEn: "Poetry Hour",
    titleUr: "شاعری",
    descriptionEn: null,
    descriptionUr: null,
    programmeType: "Poetry Hour",
    programmeDate: "2026-10-12",
    startTime: "18:30",
    endTime: "19:30",
    timezone: "Asia/Dubai",
    externalLink: null,
    publicNote: null,
  };
  assert.equal(radioCalendarInput.safeParse(valid).success, true);
  assert.equal(radioCalendarInput.safeParse({ ...valid, timezone: "Europe/Berlin" }).success, false);
  assert.equal(radioCalendarInput.safeParse({ ...valid, programmeType: "Legacy playlist" }).success, false);
  assert.equal(radioCalendarInput.safeParse({ ...valid, programmeDate: "2026-02-30" }).success, false);
  assert.equal(radioCalendarInput.safeParse({ ...valid, unexpectedField: true }).success, false);
  assert.equal(radioCalendarInput.safeParse({ ...valid, endTime: valid.startTime }).success, false);
});

test("weekly range contains seven date-based days and rejects invalid dates", () => {
  assert.deepEqual(calendarWeekRange("2026-10-12"), { start: "2026-10-12", end: "2026-10-19" });
  assert.equal(calendarWeekRange("2026-02-30"), null);
});
