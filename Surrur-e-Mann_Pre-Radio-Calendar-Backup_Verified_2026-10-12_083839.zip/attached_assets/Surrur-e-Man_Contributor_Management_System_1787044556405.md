# Surrur-e-Man — Contributor Management, RBAC & Content Approval System

## Master Implementation Request

You are working on the existing production Surrur-e-Man website and its existing Admin Panel.

**IMPORTANT:** This is an EXISTING production application.

- DO NOT rebuild the application.
- DO NOT replace the existing architecture.
- DO NOT remove or break any existing functionality.
- DO NOT modify the existing visual identity unnecessarily.
- Implement this feature as an additive production-grade module.

---

## 1. Primary Objective

Create a complete **Contributor Management System** inside the existing Admin Panel.

The Main Admin must be able to create an **UNLIMITED** number of Contributor accounts.

Initially, support at least 5 active Contributors, but **do not hard-code a five-user limit**.

The system must support 5, 10, 20, 50, 100+ Contributors without requiring developer/database code changes.

---

## 2. No Shared Contributor Login

Never use one shared Contributor username/password.

Every Contributor must have an independent account and unique immutable database User ID.

The backend must automatically attach the authenticated Contributor's identity to content they create.

The Contributor must NOT manually enter their own creator identity.

---

## 3. Contributor Role

Create a dedicated role:

`CONTRIBUTOR`

### Contributor CAN

- Login
- View Contributor Dashboard
- Create Poet
- Select an existing Poet
- Create Poem/Kalam
- Edit their own pending submissions
- Submit content for approval
- View their own submitted content
- View approval status
- View rejection reason
- View their own content history

### Contributor CANNOT

- Publish content
- Approve content
- Directly make content live
- Manage Admin users
- Manage Developer users
- Manage Contributors
- Change user roles
- Access system settings
- Access technical/database controls
- Delete approved/published content
- Modify another Contributor's submissions
- Bypass the approval workflow

Contributor must never have direct publishing authority.

---

## 4. Admin Panel — Contributor Management

Add:

**Admin Panel → Users / Contributors**

Recommended structure:

- Dashboard
- Poems / Kalam
- Poets
- Videos
- Categories
- Users
  - Admins
  - Developers
  - Contributors
- Settings

Integrate naturally with the existing Admin Panel UI.

---

## 5. Contributor Management Page

Create:

**Admin Panel → Users → Contributors**

Display:

- Name
- Email / Username
- Status
- Role
- Created Date
- Last Login
- Total Submissions
- Pending
- Approved
- Rejected
- Actions

Actions:

- View
- Edit
- Reset Password
- Disable
- Enable
- View Content
- Deactivate

Use confirmation dialogs for security-sensitive actions.

---

## 6. Add Contributor

Admin must have:

**+ Add Contributor**

Required:
- Full Name
- Email / Username
- Temporary Password

Optional:
- Profile/display name
- Phone number if supported
- Notes

Role must automatically be:

`CONTRIBUTOR`

Do not allow a normal Admin to create ADMIN or DEVELOPER roles through this form.

---

## 7. Unique User ID

Every Contributor must receive a unique immutable database User ID.

The User ID must never change when password, email, or display name changes.

Content ownership must reference this immutable User ID.

---

## 8. Content Ownership / Attribution

Every Poet/Poem/Kalam created by a Contributor must record:

- createdByUserId
- creator relationship/name where appropriate
- createdAt

For poems, support where compatible with the existing schema:

- id
- title
- content
- poetId
- status
- createdByUserId
- createdAt
- updatedAt
- approvedByUserId
- approvedAt
- rejectedByUserId
- rejectedAt
- rejectionReason

Adapt this to the existing database/ORM rather than creating a conflicting duplicate schema.

---

## 9. Never Reuse Old Contributor Accounts

If a Contributor leaves, do not delete their identity if deletion would destroy attribution/history.

Instead:

`DISABLED / DEACTIVATED`

Their historical content must remain permanently associated with their original User ID.

Their account cannot log in, but their history remains.

---

## 10. New Contributor Gets a New Identity

When replacing an old Contributor:

Do NOT reuse:

- Old User ID
- Old content ownership
- Old audit history

Create a completely new account with a new User ID.

Prefer unique email/username to avoid identity confusion.

---

## 11. Password Management

Admin must have:

**Reset Password**

Passwords must NEVER be stored as plaintext.

Reuse the existing secure authentication/password hashing system.

Admin must NOT be able to view the existing password.

Admin may:

- Reset password
- Generate temporary password
- Disable account
- Force password change on next login

---

## 12. Account Deactivation Security

When a Contributor is disabled/deactivated:

1. Prevent new login.
2. Invalidate active sessions/tokens where supported.
3. Revoke refresh tokens where supported.
4. Prevent API access using Contributor privileges.
5. Preserve all historical content.
6. Preserve audit logs.
7. Preserve creator attribution.

A removed Contributor must not continue using an already-open session.

---

## 13. Contributor Dashboard

Create a dedicated Contributor Dashboard.

Show:

### My Content

Statistics:

- Total Submissions
- Pending
- Approved
- Rejected
- Published

Contributor should only see content they are authorized to see.

---

## 14. My Submissions

Create:

**My Submissions**

Each record shows:

- Poem title
- Poet
- Created date
- Status
- Last updated
- Rejection reason if rejected

Statuses may include:

- DRAFT
- PENDING
- APPROVED
- REJECTED
- PUBLISHED

If the existing application already has a status model, integrate with it rather than creating conflicting duplicate statuses.

---

## 15. Approval Workflow

Contributor:

Create content → Save → Submit for Approval → PENDING → Admin/authorized Developer reviews → APPROVE or REJECT.

Approved content becomes live/published according to the existing publishing architecture.

Rejected content shows the reason to the Contributor.

Contributor must never bypass approval.

---

## 16. Admin Approval Queue

Add:

**Pending Approvals**

Show:

- Poem/Kalam
- Poet
- Submitted By
- Submission Date
- Status
- Actions

Actions:

- View
- Edit if authorized
- Approve
- Reject

---

## 17. Approval Audit

When approved, record:

- approvedByUserId
- approvedAt

When rejected, record:

- rejectedByUserId
- rejectedAt
- rejectionReason

Never change status without preserving who performed the action.

---

## 18. Audit Log

Track important actions:

- Contributor created
- Contributor edited
- Contributor disabled
- Contributor enabled
- Password reset
- Poem created
- Poem edited
- Poem submitted
- Poem approved
- Poem rejected
- Account deactivated

Where possible record:

- actorUserId
- action
- target type
- target ID
- timestamp
- relevant metadata

---

## 19. Filtering

Admin can filter content by:

- Contributor
- Status
- Poet
- Date
- Published / Pending / Rejected

---

## 20. Search

Contributor management search should support:

- Name
- Email
- Username

Use server-side search where appropriate.

---

## 21. Contributor Profile

Admin can open:

**View Contributor**

Show:

- Name
- Email
- Account Status
- Created Date
- Last Login
- Total Poems
- Pending
- Approved
- Rejected
- Published
- Recent submissions
- Activity history

Also provide:

**View All Content**

---

## 22. Account Status

Use:

`ACTIVE`

`DISABLED`

Optionally:

`PENDING_SETUP`

Do not physically delete Contributor accounts by default.

Use soft deactivation so attribution remains intact.

---

## 23. Role-Based Access Control

Enforce permissions at BOTH:

1. Frontend/UI level
2. Backend/API/server level

Hiding buttons is NOT security.

Unauthorized backend requests must return:

`403 Forbidden`

---

## 24. Security Requirements

Implement/reuse:

- Secure password hashing
- Session/token validation
- Backend role verification
- Authorization middleware
- 403 responses for unauthorized actions
- Input validation
- Server-side validation
- Protection against privilege escalation
- Protection against IDOR/insecure direct object references
- Rate limiting where supported
- Secure session invalidation
- No plaintext passwords
- No credentials in frontend code
- No sensitive credentials in logs

---

## 25. Database Requirements

FIRST inspect the existing database schema.

Reuse existing:

- User model
- Authentication system
- Session system
- Role system
- Poem model
- Poet model

Only add the minimum required fields/tables/indexes.

Potential additions:

### User
- role
- status

### Poem
- createdByUserId
- approvedByUserId
- rejectedByUserId
- approval timestamps
- rejectionReason

### AuditLog
- id
- actorUserId
- action
- targetType
- targetId
- metadata
- createdAt

Adapt names to existing conventions.

---

## 26. Database Migration

Create a safe migration.

DO NOT:

- Reset production database
- Wipe existing data
- Delete existing poems
- Delete existing poets
- Break existing ownership
- Remove existing Admin/Developer accounts

Existing published content must remain published.

---

## 27. Existing Admin + Developer

There are already existing privileged accounts.

Do NOT remove, downgrade, reset, or break them.

Integrate CONTRIBUTOR alongside existing roles.

---

## 28. Admin vs Developer

Respect the existing distinction between:

`ADMIN`

and

`DEVELOPER`

Main Admin should be able to:

- Add Contributor
- Edit Contributor
- Disable Contributor
- Enable Contributor
- Reset Contributor password
- View Contributor content
- View activity
- Manage approval workflow according to existing permissions

Developer retains existing technical privileges.

---

## 29. No Hard-Coded Five-User Limit

Five is only the initial planned number.

DO NOT implement:

`MAX_CONTRIBUTORS = 5`

DO NOT create five fixed database slots.

Use a dynamic User + Role system.

Admin can create unlimited Contributors subject only to practical infrastructure/database limits.

---

## 30. UI/UX

Maintain the existing Surrur-e-Man visual identity.

Do NOT redesign the whole Admin Panel.

Reuse existing colors, typography, cards, buttons, spacing, dark theme, and responsive behavior.

New screens must look native to the existing Admin Panel.

Admin management must be mobile-friendly.

---

## 31. Confirmation Dialogs

Require confirmation for:

- Disable Contributor
- Enable Contributor
- Reset Password
- Reject Submission
- Deactivate Account

For rejection, require a reason.

---

## 32. Rejection Workflow

When Admin rejects a poem:

Require a rejection reason.

Contributor sees:

`Status: REJECTED`

`Reason: [stored reason]`

Contributor may edit and resubmit according to the existing workflow.

Rejected content must never automatically become live.

---

## 33. Critical Ownership Security

The creator identity must come from the authenticated account.

Never trust a client-supplied:

`createdByUserId`

The backend must derive the authenticated user from the verified session/token.

This prevents a Contributor from pretending content was created by another Contributor.

---

## 34. Content Editing Rules

Contributor may edit:

- Their own DRAFT content
- Their own PENDING content if allowed by the existing workflow
- Their own REJECTED content for correction

Contributor may NOT edit:

- Another Contributor's content
- Admin-created content
- Published content unless explicitly authorized

---

# 35. Testing

Create and test at least:

- Contributor A
- Contributor B
- Contributor C
- Contributor D
- Contributor E

Then create:

- Contributor F
- Contributor G
- Contributor H

Confirm there is NO five-user limit.

---

## 36. Security Tests

Test:

1. Contributor login works.
2. Contributor cannot access Admin Dashboard.
3. Contributor cannot access User Management.
4. Contributor cannot approve.
5. Contributor cannot publish.
6. Contributor cannot modify another Contributor's content.
7. Contributor cannot change their role.
8. Contributor cannot manipulate createdByUserId.
9. Disabled Contributor cannot login.
10. Disabled Contributor's existing session is invalidated.
11. Admin can reset password.
12. Old Contributor cannot access the account after deactivation.
13. Historical content remains attributed to old Contributor.
14. New Contributor gets a completely new User ID.
15. Admin can create more than five Contributors.

---

## 37. Content Attribution Test

Contributor A creates Poem A.

Verify:

`createdByUserId = A`

Contributor B creates Poem B.

Verify:

`createdByUserId = B`

Confirm records are never mixed.

Deactivate Contributor A.

Verify Poem A still shows:

`Created by Contributor A`

Create Contributor F.

Verify Contributor F receives a new unique User ID.

---

## 38. Approval Test

Contributor A creates a poem.

Expected:

`PENDING`

Admin sees it in:

`Pending Approvals`

Admin approves.

Expected:

`APPROVED/PUBLISHED`

according to existing workflow.

Verify:

`approvedByUserId = Admin User ID`

`approvedAt = correct timestamp`

Contributor A cannot approve their own content.

---

## 39. Rejection Test

Contributor B creates a poem.

Admin rejects it.

Rejection reason is required.

Verify:

`status = REJECTED`

`rejectedByUserId = Admin ID`

`rejectedAt = timestamp`

`rejectionReason = stored reason`

Contributor B can see the rejection reason.

---

## 40. Disable/Replace Test

Contributor C has existing content.

Admin disables Contributor C.

Verify:

- Login blocked
- Active sessions invalidated
- Existing content preserved
- Audit history preserved
- Creator attribution preserved

Create Contributor D.

Verify:

Contributor D has a completely separate user identity.

---

## 41. Regression Testing

After implementation verify:

- Public website
- Poetry pages
- Poet pages
- Search
- Load More / pagination
- Existing Admin Panel
- Existing Developer access
- Existing Admin login
- Existing content
- Existing publishing workflow
- Existing database records
- Mobile responsive UI

No unrelated functionality should break.

---

## 42. Performance

Do not load all users/content into the browser when server-side pagination is practical.

Support:

- Pagination
- Filtering
- Searching
- Indexed queries

Add appropriate indexes for:

- user role
- user status
- createdByUserId
- status
- createdAt

Only when compatible with the existing database.

---

## 43. Final Implementation Report

After implementation provide:

1. Files changed
2. Database schema changes
3. Migration created
4. New routes/endpoints
5. New permissions
6. New UI screens
7. Authentication/authorization changes
8. Audit log implementation
9. Security checks performed
10. Tests performed
11. Remaining limitations, if any

Do not claim a test passed unless it was actually run.

---

## 44. Critical Implementation Rule

Before changing code:

FIRST inspect the existing architecture.

Identify:

- Current authentication
- Current User model
- Current roles
- Current Admin/Developer roles
- Current session/token system
- Current database
- Current Poem schema
- Current Poet schema
- Current Admin Panel structure
- Existing publishing workflow

Then implement Contributor functionality using the existing architecture.

DO NOT:

- Create a parallel authentication system
- Create duplicate User/Auth tables
- Create a duplicate database
- Replace existing authentication
- Rewrite unrelated parts of the application

---

# 45. Definition of Done

Feature is complete only when:

✓ Admin can create Contributors  
✓ No hard-coded five-user limit  
✓ Admin can create unlimited Contributors  
✓ Every Contributor has an independent account  
✓ Every Contributor has a unique immutable User ID  
✓ Contributor role is enforced  
✓ Contributor can create Poet/Poem content  
✓ Contributor cannot publish directly  
✓ Content automatically records creator identity  
✓ Admin can see who submitted each item  
✓ Admin can approve/reject submissions  
✓ Rejection reason is stored  
✓ Approval identity is stored  
✓ Audit trail exists  
✓ Contributor can see their own submissions  
✓ Admin can filter content by Contributor  
✓ Admin can reset passwords  
✓ Admin can disable accounts  
✓ Disabled users cannot login  
✓ Existing sessions are invalidated where supported  
✓ Old Contributor history remains preserved  
✓ Old User IDs are never reused  
✓ New Contributors receive new identities  
✓ Existing Admin works  
✓ Existing Developer works  
✓ Existing public website works  
✓ Existing content remains intact  
✓ Database is migrated safely  
✓ Mobile Admin UI works  
✓ Security is enforced server-side  
✓ More than five Contributors can be created  
✓ No unrelated functionality is broken

**IMPORTANT:** Do not stop after creating the UI. The complete backend + database + authentication + authorization + audit + approval workflow must be implemented and tested.
